package com.games;

import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

public class Troups {
	
	static Map<String, UnitType> troupResource;
	//static Map<String, UnitType> usedResource;
	
	public static void main(String[] args) {
		System.out.println("Initilizing troups in the system");
		Troups troup = new Troups();
		troup.initilizeTroups();
		
		System.out.println("######################################################################################");
		System.out.println("                                                     ");
				
		System.out.println(troup.getTroupResource());
		System.out.println("######################################################################################");
		System.out.println("######################################################################################");
		System.out.println("                                                     ");
		
		Map<String, UnitType> usedResource = new ConcurrentHashMap<String, UnitType>();
		while (true) { // Infinite loop
		    System.out.println("                                                     ");
		    System.out.println("IMPORTANT:: If available resources are exhausting, TYPE 999 to free the resources");
		    System.out.print("Please enter count of troops required (MAX supported integer value is 500) > ");
		    Scanner input = new Scanner(System.in);	    
		    
		    try {
			    int troupsCount = input.nextInt();  // Read input from console
			    	
			    if (troupsCount == 999) {
			    	if (usedResource.size() > 0) {
			    		troup.initilizeTroups();
			    		usedResource = new ConcurrentHashMap<String, UnitType>();
			    		System.out.println("Resource has been made available for consumption");
						continue;
			    	} else {
			    		System.out.println("WARN: Currently no resources are allocated");
						continue;
			    	}
			    } else if (troupsCount > 500) {
			    	System.out.println("Please input a valid integer value below 501");
					continue;
			    } else {
			    	try {
				    	OfferedTroups troups = new OfferedTroups(troupsCount, troup.getTroupResource());
				    	System.out.println(troups);
				    	
				    	
				    	for (int index = 0; index < troup.getTroupResource().size(); index++) {
				    		UnitType entry = usedResource.get(troups.getTroups()[index].name);
				    		
				    		UnitType orignal = troupResource.get(troups.getTroups()[index].name);
				    		if (entry == null) {
				    			usedResource.put(troups.getTroups()[index].name, troups.getTroups()[index]);
				    		} else {			    			
				    			int usedResources = entry.getAvailableCount();			    			
				    			troups.getTroups()[index].availableCount = usedResources + troups.getTroups()[index].getAvailableCount();
				    			if (troups.getTroups()[index].availableCount < orignal.getUnitCount()) {
					    			usedResource.remove(entry.getName());
					    			usedResource.put(troups.getTroups()[index].name, troups.getTroups()[index]);
				    			} else {				    				
				    				throw new Exception("Resources are exhausting for "+orignal.getName()+", resetting the resources");
				    			}
				    		}			    		
						}
			    	} catch(Exception exp) {
			    		exp.printStackTrace();
			    		troup.initilizeTroups();
			    		usedResource = new ConcurrentHashMap<String, UnitType>();
			    		continue;
			    	}    	
			    				    	
			    }
			} catch (Exception e) {
				System.out.println("Please input a valid integer value below 500");
				continue;
			}
	

		    System.out.println("######################################################################################");
		    System.out.println("                                                     ");
		    System.out.println("######################################################################################");
			
			System.out.println("AVAILABLE RESOURCES BALANCE: "+troup.getTroupResource());			
			System.out.println("######################################################################################");
			
			System.out.println("CONSUMED RESOURCES: "+usedResource);			
			System.out.println("######################################################################################");
		} // Infinite loop
	}
	
	//TODO: Can be made configurable by reading from some properties file
	private void initilizeTroups() {
		troupResource = new ConcurrentHashMap<String, UnitType>();
		
		UnitType spearmen = new UnitType(Constants.SPEARMEN, Constants.UNIT_COUNT_SPEARMEN);
		troupResource.put(Constants.SPEARMEN, spearmen);
		
		UnitType swordmen = new UnitType(Constants.SWORDMEN, Constants.UNIT_COUNT_SWORDMEN);
		troupResource.put(Constants.SWORDMEN, swordmen);
		
		UnitType archers = new UnitType(Constants.ARCHER, Constants.UNIT_COUNT_ARCHER);
		troupResource.put(Constants.ARCHER, archers);
	}
	
	public static void updateResourceTroups(String troup, int requested) throws Exception {
		UnitType currenttroup = troupResource.get(troup);
		int count = currenttroup.getAvailableCount(); 
		if (count > 0) {
			//currenttroup.availableCount = count - requested;
			currenttroup.setAllocatedCount(requested);
			
			synchronized (troupResource) {
				troupResource.remove(troup);
				troupResource.put(troup, currenttroup);
			}	
		} else {
			throw new Exception("Resource exhausted");
		}
	}
	
	public Map<String, UnitType> getTroupResource() {		
		return troupResource;
	}
	
}
