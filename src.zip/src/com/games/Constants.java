package com.games;

public class Constants {

	public static final String SPEARMEN = "SPEARMEN";
	public static final int UNIT_COUNT_SPEARMEN = 1000;
	
	public static final String SWORDMEN = "SWORDMEN";
	public static final int UNIT_COUNT_SWORDMEN = 1000;
	
	public static final String ARCHER = "ARCHER";
	public static final int UNIT_COUNT_ARCHER = 1000;
}
