package com.games;

import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

// The output of the desired program
public class OfferedTroups {
	// Output of troops
	UnitType[] army;
	// Available troops from  system
	Map<String, UnitType> troupResource;
	// Request id for the output
	String id;
	
	public OfferedTroups(int count, Map<String, UnitType> troupResource) throws Exception {
		this.troupResource = troupResource;
		id = UUID.randomUUID().toString();
		army = requestTroups(count);
	}
	
	// Generates the output 
	private UnitType[] requestTroups(int requestCount) throws Exception {
		System.out.println("FOLLOWING TROOPS ARE AVAILABLE FOR THE REQUESTED COUNT ==> "+requestCount);
		System.out.println("######################################################################################");		
		int i=0;

		int[] resources = generateRandomArrayForSize(requestCount,  troupResource.size());
		UnitType[] army = new UnitType[resources.length];
		for (Iterator iterator = troupResource.values().iterator(); iterator.hasNext();) {
			UnitType type = (UnitType) iterator.next();
			army[i] = getUnitType(type,resources[i]);
			Troups.updateResourceTroups(army[i].getName(), resources[i]);
			i++;
		}		
		return army;
	}
	
	public UnitType[] getTroups() {
		return army;
	}
	
	private int[] generateRandomArrayForSize(int requestCount, int size) {
		Random randomGenerator=new Random();	
		
		int[] returnArr = new int[size];
		int count = 0;
		for (int i = 0; i < size; i++) {
			 int random = randomGenerator.nextInt(requestCount);
			 if (random < 1) {
				 random = 1;
			 }			 
			 
			 if (i == 0 && random > (requestCount - requestCount/3) ) {
				 random = randomGenerator.nextInt(requestCount);
				 if (random < 1) {
					 random = 1;
				 }
				 
			 } else {
				 count = findSumofArrays(returnArr) + random;
			 }			 
			 
			 if (i == size-1) {
				 returnArr[i] = requestCount - findSumofArrays(returnArr) ;
				 count = count - random + returnArr[i];
			 }			 
			 
			 if (requestCount > count) {
				 returnArr[i] = random;				 
			 }			 
			 
			 if (count > requestCount) {
				 count = count - random;
				 random = randomGenerator.nextInt(requestCount - findSumofArrays(returnArr) - 1);
				 if (random < 1) {
					 random = 1;
				 }
				//Ensure random is less than requestCount - Sum of Arrays - 1
				 if (random < requestCount - findSumofArrays(returnArr) - 1) {
					 returnArr[i] = random;
					 count = count + random;
				 }
			 }		 
		}
		return returnArr;
	
	}	
	
	
	private int findSumofArrays(int[] returnArr)  {
		int sum = 0;
		for (int i = 0; i < returnArr.length; i++) {
			sum = sum + returnArr[i];
		}		
		return sum;
		
	}
	
	private UnitType getUnitType(UnitType type, int size) {	
		UnitType armyType = new UnitType(type.getName(), size);			
		return armyType;		
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder("[Request Id - " + this.id + "] \n");
		for (int i = 0; i < army.length; i++) {
			UnitType type = army[i];			
			sb.append(type.toString());
			sb.append("  ");
		}
		return sb.toString();
	}

}
