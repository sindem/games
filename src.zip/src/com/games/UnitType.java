package com.games;

public class UnitType {
	
	String name;
	int unitCount;
	int availableCount;
	int allocatedCount;
	
	public UnitType(String name, int unitCount) {
		this.name = name;
		this.unitCount = unitCount;
		this.availableCount = unitCount;
	}
	
	public String getName() {
		return this.name;
	}

	public int getAvailableCount() {
		return this.availableCount;
	}
	
	public int getUnitCount() {
		return this.unitCount;
	}
	
	public void setAllocatedCount(int requestedCount) throws Exception {
		if (this.unitCount >= this.allocatedCount) {
			this.allocatedCount = this.allocatedCount + requestedCount;
			this.availableCount = this.availableCount - requestedCount;
		} else {			
			throw new Exception("Could not allocated the unit type "+this.name+", since the available count is less than requested count");
		}
	}
	
	public String toString() {
		return "[" + this.name + "] - Count: "+this.availableCount;
	}
	
}
